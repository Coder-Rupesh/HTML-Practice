from django.urls import path
from.import views

urlpatterns = [
    path("",views.index,name="ShopHome"),
    path("about/",views.about,name="AboutUs"),
    path("contact/",views.contact,name="ContactUs"),
    path("tracker/",views.tracker,name="TrackinStatus"),
    path("search/",views.search,name="Searching"),
    path("products/<int:myid>",views.productview,name="Products"),
    path("checkout",views.checkout,name="Checkout"),
]
 
